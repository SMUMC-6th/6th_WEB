import React from "react";

export default function Hero() {
  return <div className="Hero">HERO</div>;
}
