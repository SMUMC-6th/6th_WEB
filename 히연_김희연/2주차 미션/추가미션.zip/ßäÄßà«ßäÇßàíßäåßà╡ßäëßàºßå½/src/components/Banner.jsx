import React from "react";

export default function Banner() {
  return <div className="Banner">BANNER</div>;
}
