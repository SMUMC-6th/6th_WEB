import React from "react";

export default function Main() {
  return <div className="Main">MAIN</div>;
}
