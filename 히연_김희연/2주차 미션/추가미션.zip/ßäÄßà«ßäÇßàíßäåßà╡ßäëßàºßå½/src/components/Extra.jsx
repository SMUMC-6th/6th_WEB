import React from "react";

export default function Extra() {
  return <div className="Extra">Extra</div>;
}
