import React from "react";
import Banner from "./Banner";

export default function footer() {
  return (
    <div className="Footer">
      <Banner />
    </div>
  );
}
