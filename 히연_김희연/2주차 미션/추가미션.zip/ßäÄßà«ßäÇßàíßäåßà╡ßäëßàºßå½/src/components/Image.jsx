import React from "react";

export default function Image() {
  return <div className="Image">IMAGE</div>;
}
