import React from "react";

export default function Menu() {
  return <div className="Menu">MENU</div>;
}
